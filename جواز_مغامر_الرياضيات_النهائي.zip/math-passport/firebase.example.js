// مثال هيكلي للمرحلة الثانية فقط. لا تضع مفاتيح خدمة Admin في المتصفح.
// استخدمي Firebase Authentication للمستخدمين وCloud Firestore للبيانات.
// بيانات الطالب يجب أن تُقرأ وفق uid المصادق عليه، لا عبر رمز مكشوف في قاعدة البيانات.
export const firebaseConfig = {
  apiKey: "YOUR_WEB_API_KEY",
  authDomain: "YOUR_PROJECT.firebaseapp.com",
  projectId: "YOUR_PROJECT",
  storageBucket: "YOUR_PROJECT.firebasestorage.app",
  messagingSenderId: "YOUR_SENDER_ID",
  appId: "YOUR_APP_ID"
};
